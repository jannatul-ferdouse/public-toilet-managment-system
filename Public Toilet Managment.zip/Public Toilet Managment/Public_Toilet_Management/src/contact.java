
/**
 *
 * @author Md. Imrul Hassan
 */
public class contact {
    
    private Integer cid;
    private String fname;
    private String lname;
    private String groupc;
    private String mobile;
    private String TxnID;
    private String address;
    private byte[] pic;
    private int uid;

    
    // Alt + ins
    //to generate constructor & getters & setters

    public contact() {}
    
    
    
    public contact(Integer cid, String fname, String lname, String groupc, String mobile, String TxnID, String address, byte[] pic, int uid) {
        this.cid = cid;
        this.fname = fname;
        this.lname = lname;
        this.groupc = groupc;
        this.mobile = mobile;
        this.TxnID = TxnID;
        this.address = address;
        this.pic = pic;
        this.uid = uid;
    }

    public int getCid() {
        return cid;
    }

    public void setCid(int cid) {
        this.cid = cid;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getGroupc() {
        return groupc;
    }

    public void setGroupc(String groupc) {
        this.groupc = groupc;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getTxnID() {
        return TxnID;
    }

    public void setTxnID(String TxnID) {
        this.TxnID = TxnID;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public byte[] getPic() {
        return pic;
    }

    public void setPic(byte[] pic) {
        this.pic = pic;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }
    

    
}
